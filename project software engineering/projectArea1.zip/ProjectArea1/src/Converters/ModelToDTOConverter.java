package Converters;

import java.util.Iterator;
import Application.LogControl;
import Classes.Face;
import Classes.Imported3dModel;
import Classes.Line;
import Classes.Point;
import Classes.Polygon;
import Classes.Roof;
import DTOs.BaseDataDTO;
import DTOs.FaceDTO;
import DTOs.LineDTO;
import DTOs.PointDTO;
import DTOs.PolygonDTO;
import DTOs.RoofDTO;
import DTOs.RoofModelDTO;

public class ModelToDTOConverter {
	public static RoofModelDTO ConvertImportedModelToRoofModelDTO(Imported3dModel importedModel)
	{
		LogControl.InfoLog("Starting create DTO for report "+importedModel.getReportId());
		RoofModelDTO roofModel = new RoofModelDTO();
		
		//Create BaseDataDTO
		BaseDataDTO baseData = new BaseDataDTO(importedModel.getReportId(),
												importedModel.getLengthUnit(),
												importedModel.getLocation().getComposeAddress(),
												importedModel.getLocation().getCoordinates());
		roofModel.setBaseData(baseData);
		
		//Create RoofDTOs
		for(Roof roof : importedModel.getRoofs())
		{
			RoofDTO roofDto = new RoofDTO(roof.getId(), importedModel.getStructureOrientation());
			
			//Create FaceDTOs
			Iterator<String> facesIterator = roof.getFaces().keySet().iterator();
			while(facesIterator.hasNext()){
				Face face = (Face) roof.getFaces().get(facesIterator.next());
				FaceDTO faceDTO = new FaceDTO(face.getId(), face.getType());
				faceDTO.setChildren(face.getChildren());
				
				//Create PolygonDTO
				Polygon polygon = face.getPolygon();
				PolygonDTO polygonDTO = new PolygonDTO(polygon.getId(),
													polygon.getOrientation(),
													polygon.getPitch(),
													polygon.getSize(),
													polygon.getUnroundedSize());
				polygonDTO.setPitchuom(polygon.getPitchuom());
				polygonDTO.setSizeuom(polygon.getSizeuom());
				polygonDTO.setMaterial(polygon.getMaterial());
				
				//Create LineDTOs
				for(String lineId : polygon.getLineIds())
				{
					Line line = roof.getLines().get(lineId);
					LineDTO lineDTO = new LineDTO(line.getId(), line.getType());
					
					//CreatePointDTOs
					for (String pointId : line.getPointIds())
					{
						Point point = roof.getPoints().get(pointId);
						PointDTO pointDTO = new PointDTO(point.getId(), point.getCoordinateX(), point.getCoordinateY(), point.getCoordinateZ());
						
						lineDTO.getPoints().add(pointDTO);
					}
					
					polygonDTO.getLines().add(lineDTO);
				}		
				
				faceDTO.setPolygon(polygonDTO);
								
				roofDto.getFacesArray().add(faceDTO);
			}

			roofModel.getRoofsArray().add(roofDto);
		}
		
		LogControl.InfoLog("The DTO for report " + importedModel.getReportId() + " has been created successfully.");
		
		return roofModel;
	} 
}
