package DTOs;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class PolygonDTO {
	@SerializedName(value = "Id")
	private String id;
	@SerializedName(value = "Orientation")
	private Double orientation;
	@SerializedName(value = "Pitch")
	private Double pitch;
	@SerializedName(value = "Size")
	private Double size;
	@SerializedName(value = "UnroundedSize")
	private Double unroundedSize;
	@SerializedName(value = "Lines")
	private ArrayList<LineDTO> lines;
	@SerializedName(value = "Pitchuom")
	private String pitchuom;
	@SerializedName(value = "Sizeuom")
	private String sizeuom;
	@SerializedName(value = "Material")
	private String material;
	
	
	public PolygonDTO(String id, Double orientation, Double pitch, Double size, Double unroundedSize) {		
		this.id = id;
		this.orientation = orientation;
		this.pitch = pitch;
		this.size = size;
		this.unroundedSize = unroundedSize;
		this.lines = new ArrayList<LineDTO>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Double getOrientation() {
		return orientation;
	}

	public void setOrientation(Double orientation) {
		this.orientation = orientation;
	}

	public Double getPitch() {
		return pitch;
	}

	public void setPitch(Double pitch) {
		this.pitch = pitch;
	}

	public Double getSize() {
		return size;
	}

	public void setSize(Double size) {
		this.size = size;
	}

	public Double getUnroundedSize() {
		return unroundedSize;
	}

	public void setUnroundedSize(Double unroundedSize) {
		this.unroundedSize = unroundedSize;
	}

	public ArrayList<LineDTO> getLines() {
		return lines;
	}

	public void setLines(ArrayList<LineDTO> lines) {
		this.lines = lines;
	}

	public String getPitchuom() {
		return pitchuom;
	}

	public void setPitchuom(String pitchuom) {
		this.pitchuom = pitchuom;
	}

	public String getSizeuom() {
		return sizeuom;
	}

	public void setSizeuom(String sizeuom) {
		this.sizeuom = sizeuom;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}	
}
