package DTOs;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class FaceDTO {
	@SerializedName(value = "Id")
	private String id;
	@SerializedName(value = "Type")
	private String type;
	@SerializedName(value = "Children")
	private ArrayList<String> children;
	@SerializedName(value = "Polygon")
	private PolygonDTO polygon;
	
	public FaceDTO(String id, String type) {		
		this.id = id;
		this.type = type;
		this.children = new ArrayList<String>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ArrayList<String> getChildren() {
		return children;
	}

	public void setChildren(ArrayList<String> children) {
		this.children = children;
	}

	public PolygonDTO getPolygon() {
		return polygon;
	}

	public void setPolygon(PolygonDTO polygon) {
		this.polygon = polygon;
	}	
}
