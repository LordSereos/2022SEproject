package DTOs;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class RoofModelDTO {
	@SerializedName(value = "BaseData")
	private BaseDataDTO baseData;
	@SerializedName(value = "Roofs")
	private ArrayList<RoofDTO> roofsArray;
	
	public RoofModelDTO() {
		roofsArray = new ArrayList<RoofDTO>();
	}

	public BaseDataDTO getBaseData() {
		return baseData;
	}

	public void setBaseData(BaseDataDTO baseData) {
		this.baseData = baseData;
	}

	public ArrayList<RoofDTO> getRoofsArray() {
		return roofsArray;
	}

	public void setRoofsArray(ArrayList<RoofDTO> roofsArray) {
		this.roofsArray = roofsArray;
	}	
}
