package DTOs;

import java.util.ArrayList;

import com.google.gson.annotations.SerializedName;

public class RoofDTO {
	@SerializedName(value = "Id")
	private String id;
	@SerializedName(value = "Orientation")
	private Double orientation;
	@SerializedName(value = "Faces")
	private ArrayList<FaceDTO> facesArray;
	
	public RoofDTO(String id, Double orientation) {		
		this.id = id;
		this.orientation = orientation;
		this.facesArray = new ArrayList<FaceDTO>();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Double getOrientation() {
		return orientation;
	}

	public void setOrientation(Double orientation) {
		this.orientation = orientation;
	}

	public ArrayList<FaceDTO> getFacesArray() {
		return facesArray;
	}

	public void setFacesArray(ArrayList<FaceDTO> facesArray) {
		this.facesArray = facesArray;
	}	
}
